# Day 4: Local Practice

### In Class Activities:
- Brand new, *local only* repositories
- Advanced topics that have to do with Git under the hood
  - `git init`
  - What's really in the `.git` folder
  - `git reset`, all three types (`--soft`, `--mixed`, & `--hard`)
  - `git cherry-pick`
  - `git reflog`
  - `git rebase`
- When to change history, and how  

### After Class Activities:
- None! But, remember you can always ask more questions in 1:1 sessions or through issues. :sparkles:
