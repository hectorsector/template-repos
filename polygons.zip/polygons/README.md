![](http://i.imgur.com/NcsRW1q.png)

**[PLAY IT HERE (http://ncase.me/polygons)](http://ncase.me/polygons)**

---

This playable post is [public domain (CC0)](http://creativecommons.org/publicdomain/zero/1.0).

This repository is also being used as a part of GitHub training, to practice Git and GitHub.

Please feel free to use this in your classrooms,
make video/picture/text adaptations,
or modify the source code!
Attribution is not mandatory, but super appreciated.
We are [Vi Hart](http://vihart.com/) and [Nicky Case](http://ncase.me/).

Show us how you're using and remixing Parable of the Polygons!    
Tweet us at
[@vihartvihart](https://twitter.com/vihartvihart) and
[@ncasenmare](https://twitter.com/ncasenmare).
